# Runbook: Use OCP's built-in Prometheus/Alertmanager for Px-Backup (BYOP)

## Goal

Point Px-Backup at OpenShift's built-in user-workload-monitoring stack (Thanos
Querier + user Alertmanager) instead of deploying Px-Backup's dedicated
Prometheus/Alertmanager, and let OCP scrape Px-Backup's `pxbackup_*` metrics.

Three things have to happen, in order:
1. OCP user-workload monitoring must be enabled and ready (ConfigMaps → TLS
   secrets + `thanos-ruler` SA).
2. Px-Backup needs credentials (cert + bearer token) in its own namespace to
   reach Thanos/Alertmanager.
3. Px-Backup's Helm values must switch from "deploy your own stack" to "use
   these external endpoints".

## Target end state (values delta)

Apply this on top of your existing values — every line is required for BYOP,
not optional tuning:

```yaml
isOpenshift: true          # tells the chart this is an OpenShift deployment

pxbackup:
  enabled: true
  deployDedicatedMonitoringSystem: false   # stop deploying Px-Backup's own Prometheus/Alertmanager
  enableExternalMetricsScraping: true      # publish the ServiceMonitor OCP needs to scrape pxbackup_* metrics
                                            # (pxbackup_backup_object_info, pxbackup_backup_volume_info,
                                            #  pxbackup_virtual_machine_info, pxbackup_virtual_machine_resource_info)

  prometheusEndpoint: "https://thanos-querier.openshift-monitoring.svc:9091"
  alertmanagerEndpoint: "https://alertmanager-user-workload.openshift-user-workload-monitoring.svc:9095"
  prometheusSecretName: "prometheus-cred"    # secrets created in Step 1, in the px-backup namespace
  alertmanagerSecretName: "alertmanager-cred"

  usePxBackupEmailAlertTemplate: true
```

Once `deployDedicatedMonitoringSystem: false` is set, these sizing values stop
mattering (OCP owns storage/retention/replicas now) — safe to leave them in
the file, but no need to tune them for this path:
`persistentStorage.prometheus.storage`, `persistentStorage.prometheus.retentionSize`,
`persistentStorage.alertManager.storage`, `pxbackup.prometheus.replicas`,
`pxbackup.alertmanager.replicas`.

## Step 1: Cluster-side prep — enable OCP monitoring, wait, create credentials

This is one idempotent script: enable user-workload monitoring + Alertmanager,
wait (with a timeout, not an infinite loop) for the objects Px-Backup actually
needs, then create/refresh the two credential secrets in the `px-backup`
namespace.

```bash
export PXBACKUP_NAMESPACE=px-backup
export TOKEN_TTL=8760h   # 1 year — pick your own rotation policy; keep it consistent everywhere below

# 1a. Enable user-workload monitoring + user Alertmanager (no-op if already enabled)
oc apply -f - <<'EOF'
apiVersion: v1
kind: ConfigMap
metadata:
  name: cluster-monitoring-config
  namespace: openshift-monitoring
data:
  config.yaml: |
    enableUserWorkload: true
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: user-workload-monitoring-config
  namespace: openshift-user-workload-monitoring
data:
  config.yaml: |
    alertmanager:
      enabled: true
    enableAlertmanagerConfig: true
EOF

# 1b. Wait for the three prerequisites, with a timeout instead of an infinite poll
timeout 300 bash -c '
  until oc get secret prometheus-user-workload-tls -n openshift-user-workload-monitoring >/dev/null 2>&1 \
     && oc get secret alertmanager-user-workload-tls -n openshift-user-workload-monitoring >/dev/null 2>&1 \
     && oc get sa thanos-ruler -n openshift-user-workload-monitoring >/dev/null 2>&1; do
    echo "waiting for OCP user-workload monitoring objects..."
    sleep 10
  done
' || { echo "timed out waiting for user-workload monitoring — see Troubleshooting"; exit 1; }
echo "OCP user-workload monitoring is ready"

# 1c. Create/refresh Px-Backup's credential secrets (idempotent: apply, not delete-then-create)
PROMETHEUS_CERT=$(oc get secret prometheus-user-workload-tls -n openshift-user-workload-monitoring \
  --template='{{ index .data "tls.crt" }}' | base64 -d)
PROMETHEUS_TOKEN=$(oc create token prometheus-k8s -n openshift-monitoring --duration="$TOKEN_TTL")
ALERTMANAGER_CERT=$(oc get secret alertmanager-user-workload-tls -n openshift-user-workload-monitoring \
  --template='{{ index .data "tls.crt" }}' | base64 -d)
ALERTMANAGER_TOKEN=$(oc create token thanos-ruler -n openshift-user-workload-monitoring --duration="$TOKEN_TTL")

oc create secret generic prometheus-cred -n "$PXBACKUP_NAMESPACE" \
  --from-literal=cert="$PROMETHEUS_CERT" --from-literal=token="$PROMETHEUS_TOKEN" \
  --dry-run=client -o yaml | oc apply -f -

oc create secret generic alertmanager-cred -n "$PXBACKUP_NAMESPACE" \
  --from-literal=cert="$ALERTMANAGER_CERT" --from-literal=token="$ALERTMANAGER_TOKEN" \
  --dry-run=client -o yaml | oc apply -f -
```

`--dry-run=client -o yaml | oc apply -f -` replaces the old
delete-then-recreate dance — safe to re-run any time tokens need rotating.

## Step 2: Install or upgrade Px-Backup with the values delta above

New install:

```bash
helm install px-central <chart-source> -n px-backup -f values.yaml
```

Upgrade of an existing install — **known chart limitation:**
`pxcentral-post-install-hook` is a plain Job (not annotated as a Helm hook), so
`helm upgrade` fails trying to patch its immutable `spec.template`. Delete it
first:

```bash
helm get values -n px-backup px-central -o yaml > current.yaml
kubectl delete job pxcentral-post-install-hook -n px-backup

helm upgrade px-central <chart-source> -n px-backup -f current.yaml \
  --set isOpenshift=true \
  --set pxbackup.deployDedicatedMonitoringSystem=false \
  --set pxbackup.enableExternalMetricsScraping=true \
  --set pxbackup.prometheusEndpoint="https://thanos-querier.openshift-monitoring.svc:9091" \
  --set pxbackup.alertmanagerEndpoint="https://alertmanager-user-workload.openshift-user-workload-monitoring.svc:9095" \
  --set pxbackup.prometheusSecretName=prometheus-cred \
  --set pxbackup.alertmanagerSecretName=alertmanager-cred
```

## Step 3: Verify

```bash
# ServiceMonitor exists → OCP Prometheus can discover Px-Backup as a scrape target
oc get servicemonitors.monitoring.coreos.com -n px-backup | grep px-backup-external-monitoring-sm

# pxbackup_* metrics are actually flowing through Thanos
TOKEN=$(oc create token prometheus-k8s -n openshift-monitoring --duration="$TOKEN_TTL")
HOST=$(oc get route thanos-querier -n openshift-monitoring -o jsonpath='{.spec.host}')

curl -sk -H "Authorization: Bearer $TOKEN" \
  "https://$HOST/api/v1/label/__name__/values" | jq '.data[] | select(startswith("pxbackup_"))'
```

Optional: a Route exposing Px-Backup's own `/metrics` (port 10001) directly —
not required for BYOP, only useful if something outside the cluster needs to
scrape Px-Backup without going through Thanos.

## Troubleshooting

| Symptom | Cause |
|---|---|
| `prometheus-user-workload-tls` / `alertmanager-user-workload-tls` not found | user-workload monitoring not enabled yet, or still reconciling — re-run Step 1a, then 1b |
| `serviceaccounts "thanos-ruler" not found` | `openshift-user-workload-monitoring` stack not ready yet |
| `prometheus-cred`/`alertmanager-cred` already exists, wrong content | harmless — Step 1c now applies idempotently, just re-run it |
| No `pxbackup_*` metrics returned | confirm `enableExternalMetricsScraping: true` landed, and that the ServiceMonitor from Step 3 actually exists |

## Sources

- Configure your Own Prometheus — Portworx Backup On-Premises Documentation
- Backup Info Metrics — External Metrics scraping on OCP
- 3.0.0 Helm Chart — Portworx Backup On-Premises Documentation
- Configure Portworx Monitoring on OpenShift — Portworx Enterprise Documentation
