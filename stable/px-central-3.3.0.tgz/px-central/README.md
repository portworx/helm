# PX-Central
PX-Central is a unified, multi-user, multi-cluster management interface.
This chart also supports following features but by default those are disabled.
  1. PX-Backup
  2. PX-License-Server

To enable each feature, follow the respective sections for detailed steps.

## Installing the Chart

To install the chart with the release name `px-central`:

Add portworx/px-central helm repository using command:
```console
$ helm repo add portworx http://charts.portworx.io/
```

Update helm repository:
```console
$ helm repo update
```

Search for portworx repo:
```console
$ helm search repo portworx
```
Output:
```console
NAME                    CHART VERSION   APP VERSION         DESCRIPTION
portworx/px-central     2.0.0        	  2.0.0      	    A Helm chart for installing PX-Central
```

Helm 3:
```console
$ helm install px-central portworx/px-central --namespace central --create-namespace
```

Helm 2:
```console
$ helm install --name px-central portworx/px-central --namespace central
```

## Uninstalling the Chart

1. To uninstall/delete the `px-central` chart:

```console
$ helm delete px-central --namespace central
```

2. To cleanup secrets and pvc:

```console
$ kubectl delete ns central
```

## Upgrading the Chart

  ### To Upgrade from >= 2.0.0 versions:
  To upgrade px-central:

  1. helm repo update

  2. helm get values --namespace central px-central -o yaml > values.yaml

  3. Delete post install job: `kubectl delete job -n central pxcentral-post-install-hook`

  4. Run following helm upgrade command to upgrade px-central chart

  Helm 3:
  ```console
  $ helm upgrade px-central portworx/px-central --namespace central -f values.yaml
  ```

  Helm 2:
  ```console
  $ helm upgrade --name px-central portworx/px-central --namespace central -f values.yaml
  ```

  ### To Upgrade from 1.2.X versions:
  In 1.2.x and previous versions , there are three charts (px-backup, px-monitor, px-license-server) which got merged into one chart(px-central)

  To upgrade from 1.2.x versions, please follow the steps mentioned [here](https://github.com/portworx/helm/blob/master/single_chart_migration/README.md)

## Advanced Configuration

### Expose PX-Central UI on ingress and access using https:

1. Create the following spec:
```
cat <<< '
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  annotations:
    ingress.bluemix.net/redirect-to-https: "True"
    kubernetes.io/ingress.class: nginx
    nginx.ingress.kubernetes.io/x-forwarded-port: "443"
  name: px-central-ui-ingress
  namespace: central
spec:
  rules:
  - host: px-central-ui.test-1.us-east.containers.appdomain.cloud
    http:
      paths:
      - backend:
          serviceName: px-central-ui
          servicePort: 80
        path: /
      - backend:
          serviceName: pxcentral-keycloak-http
          servicePort: 80
        path: /auth
  tls:
  - hosts:
    - px-central-ui.test-1.us-east.containers.appdomain.cloud
    secretName: test
' > /tmp/px-central-ui-ingress.yaml
```

Note: Change the secret and hosts based on your configuration. Also, `secretName` -> `kubernetes TLS certificates secret` is required only when you want to terminate TLS on the host/domain.
- Some examples:
  - AKS: https://docs.microsoft.com/en-us/azure/aks/ingress-own-tls
  - EKS: https://aws.amazon.com/blogs/opensource/network-load-balancer-nginx-ingress-controller-eks/

2. Apply the spec:
```console
$ kubectl apply -f /tmp/px-central-ui-ingress.yaml
```

3. Retrieve the `INGRESS_ENDPOINT` using command:
```console
$ kubectl get ingress px-central-ui-ingress --namespace central -o jsonpath="{.status.loadBalancer.ingress[0].hostname}"
```

4. Access PX-Central UI : `https://INGRESS_ENDPOINT` use default credentials (admin/admin) to login.

5. Access Keycloak UI: `https://INGRESS_ENDPOINT/auth`

### Access PX-Central UI and Keycloak using node IP:
1. Get any node public/external IP (NODE_IP) of current k8s cluster.

2. Get the node port (NODE_PORT) of service: `px-central-ui`.

3. PX-Central UI is available at: `http://NODE_IP:NODE_PORT`

4. Keycloak UI is available at: `http://NODE_IP:NODE_PORT/auth`

### Access PX-Central UI using Loadbalancer Endpoint:
1. Get the loadbalancer endpoint (LB_ENDPOINT) using following commands:
   - HOST:
   ```console
   $ kubectl get ingress --namespace {{ .Release.Namespace }} px-central-ui -o jsonpath="{.status.loadBalancer.ingress[0].hostname}"`
   ```
   - IP:
   ```console
   $ kubectl get ingress --namespace {{ .Release.Namespace }} px-central-ui -o jsonpath="{.status.loadBalancer.ingress[0].ip}"`
   ```

2. PX-Central UI endpoint: `http://LB_ENDPOINT`

3. Keycloak UI endpoint: `http://LB_ENDPOINT/auth`


# PX-Backup

Using PX-Backup, users can backup/restore Kubernetes clusters.
By default px-backup remains disabled with px-central installation.

## Enabling PX-Backup

  ### To enable PX-Backup along with px-central installation:

  Helm 3:
  ```console
  $ helm install px-central portworx/px-central --namespace central --create-namespace --set pxbackup.enabled=true
  ```

  Helm 2:
  ```console
  $ helm install --name px-central portworx/px-central --namespace central --set pxbackup.enabled=true
  ```

  ### To enable PX-Backup on already deployed px-central:

  1. helm get values --namespace central px-central -o yaml > values.yaml

  2. Delete post install job: `kubectl delete job -n central pxcentral-post-install-hook`

  3. Run following helm upgrade command to enable px-backup for same px-central chart

  Helm 3:
  ```console
  $ helm upgrade px-central portworx/px-central --namespace central --set pxbackup.enabled=true
  ```

  Helm 2:
  ```console
  $ helm upgrade --name px-central portworx/px-central --namespace central --set pxbackup.enabled=true
  ```

## Disabling PX-Backup

1. helm get values --namespace central px-central -o yaml > values.yaml

2. Delete post install job: `kubectl delete job -n central pxcentral-post-install-hook`

3. Run following helm upgrade command to disable px-backup for same px-central chart

To disable PX-Backup:

Helm 3:
```console
$ helm upgrade px-central portworx/px-central --namespace central --set pxbackup.enabled=false
```

Helm 2:
```console
$ helm upgrade --name px-central portworx/px-central --namespace central --set pxbackup.enabled=false
```

## Advanced Configuration

### Configure custom ca certificate:
1. Create secret with ca certificates into release namespace.

Example:
```
apiVersion: v1
stringData:
  ca.crt: |
    -----BEGIN CERTIFICATE-----
    MIIEczCCA1ugAwIBAgIBADANBgkqhkiG9w0BAQQFAD..AkGA1UEBhMCR0Ix
    EzARBgNVBAgTClNvbWUtU3RhdGUxFDASBgNVBAoTC0..0EgTHRkMTcwNQYD
    VQQLEy5DbGFzcyAxIFB1YmxpYyBQcmltYXJ5IENlcn..XRpb24gQXV0aG9y
    aXR5MRQwEgYDVQQDEwtCZXN0IENBIEx0ZDAeFw0wMD..TUwMTZaFw0wMTAy
    MDQxOTUwMTZaMIGHMQswCQYDVQQGEwJHQjETMBEGA1..29tZS1TdGF0ZTEU
    MBIGA1UEChMLQmVzdCBDQSBMdGQxNzA1BgNVBAsTLk..DEgUHVibGljIFBy
    aW1hcnkgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkxFD..AMTC0Jlc3QgQ0Eg
    THRkMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCg..Tz2mr7SZiAMfQyu
    vBjM9OiJjRazXBZ1BjP5CE/Wm/Rr500PRK+Lh9x5eJ../ANBE0sTK0ZsDGM
    ak2m1g7oruI3dY3VHqIxFTz0Ta1d+NAjwnLe4nOb7/..k05ShhBrJGBKKxb
    8n104o/5p8HAsZPdzbFMIyNjJzBM2o5y5A13wiLitE..fyYkQzaxCw0Awzl
    kVHiIyCuaF4wj571pSzkv6sv+4IDMbT/XpCo8L6wTa..sh+etLD6FtTjYbb
    rvZ8RQM1tlKdoMHg2qxraAV++HNBYmNWs0duEdjUbJ..XI9TtnS4o1Ckj7P
    OfljiQIDAQABo4HnMIHkMB0GA1UdDgQWBBQ8urMCRL..5AkIp9NJHJw5TCB
    tAYDVR0jBIGsMIGpgBQ8urMCRLYYMHUKU5AkIp9NJH..aSBijCBhzELMAkG
    A1UEBhMCR0IxEzARBgNVBAgTClNvbWUtU3RhdGUxFD..AoTC0Jlc3QgQ0Eg
    THRkMTcwNQYDVQQLEy5DbGFzcyAxIFB1YmxpYyBQcm..ENlcnRpZmljYXRp
    b24gQXV0aG9yaXR5MRQwEgYDVQQDEwtCZXN0IENBIE..DAMBgNVHRMEBTAD
    AQH/MA0GCSqGSIb3DQEBBAUAA4IBAQC1uYBcsSncwA..DCsQer772C2ucpX
    xQUE/C0pWWm6gDkwd5D0DSMDJRqV/weoZ4wC6B73f5..bLhGYHaXJeSD6Kr
    XcoOwLdSaGmJYslLKZB3ZIDEp0wYTGhgteb6JFiTtn..sf2xdrYfPCiIB7g
    BMAV7Gzdc4VspS6ljrAhbiiawdBiQlQmsBeFz9JkF4..b3l8BoGN+qMa56Y
    It8una2gY4l2O//on88r5IWJlm1L0oA8e4fR2yrBHX..adsGeFKkyNrwGi/
    7vQMfXdGsRrXNGRGnX+vWDZ3/zWI0joDtCkNnqEpVn..HoX
    -----END CERTIFICATE-----
kind: Secret
metadata:
  name: ca-certs
  namespace: central
```

2. Pass the secret name to chart using flag: `--set caCertsSecretName=<SECRET_NAME>`

### Expose PX-Central UI on openshift routes and access using http and https:
1. Create single route with hostname and path: `/` and point it to `px-central-ui` service.
2. Access PX-Central UI using route endpoint.
Note: Keycloak auth and Grafana UI will be accessible on same endpoint on different paths: `/auth` and `/grafana`.

## FAQ

1. How to check install logs:
   To get the logs of post install hook:
   ```console
   $ kubectl logs -f --namespace {{ .Release.Namespace }} -ljob-name=pxcentral-post-install-hook
   ```

# PX-License-Server

Using PX-License-Server, you can manage license for all your portworx clusters.
By default PX-License-Server remains disabled with px-central installation.

### Prerequisites:
- Set `px/ls=true` label to any of two worker nodes.
```console
$ kubectl label node <NODE_NAME> px/ls=true
```
- For openshift cluster:
1. Edit `privileged` scc using command : `oc edit scc privileged` and add following into `users` section : `- system:serviceaccount:<PX_BACKUP_NAMESPACE>:pxcentral-license-server` change the PX_BACKUP_NAMESPACE.
2. Enable SSH access on port 7070, To configure same add following into worker nodes where `px/ls=true` label is set:
   - `-A INPUT -p tcp -m state --state NEW -m tcp --dport 7070 -j ACCEPT` in `/etc/sysconfig/iptables` file
   - Restart iptables service: `systemctl restart iptables.service`

## Enabling PX-License-Server

  ### To enable PX-License-Server along with px-central install:

    Helm 3:
    ```console
    $ helm install px-central portworx/px-central --namespace central --create-namespace --set pxlicenseserver.enabled=true
    ```

    Helm 2:
    ```console
    $ helm install --name px-central portworx/px-central --namespace central --set pxlicenseserver.enabled=true
    ```

  ### To enable PX-License-Server on already deployed px-central

  1. helm get values --namespace central px-central -o yaml > values.yaml

  2. Delete post install job: `kubectl delete job -n central pxcentral-post-install-hook`

  3. Run following helm upgrade command to enable px-license-server for same px-central chart

  Helm 3:
  ```console
  $ helm upgrade px-central portworx/px-central --namespace central --create-namespace --set pxlicenseserver.enabled=true
  ```

  Helm 2:
  ```console
  $ helm upgrade --name px-central portworx/px-central --namespace central --set pxlicenseserver.enabled=true
  ```

## Disabling PX-License-Server

To disable PX-License-Server along with px-central:

Helm 3:
```console
$ helm upgrade px-central portworx/px-central --namespace central --create-namespace --set pxlicenseserver.enabled=false
```

Helm 2:
```console
$ helm upgrade --name px-central portworx/px-central --namespace central --set pxlicenseserver.enabled=false
```

## Parameters

The following tables lists the configurable parameters of the PX-Backup chart and their default values.

### PX-Central parameters

Parameter | Description | Default
--- | --- | ---
`persistentStorage` | Persistent storage for all px-central components | `""`
`persistentStorage.storageClassName` | Provide storage class name which exists | `""`
`persistentStorage.mysqlVolumeSize` | MySQL volume size | `"100Gi"`
`persistentStorage.keycloakThemeVolumeSize` | Keycloak frontend theme volume size | `"5Gi"`
`persistentStorage.keycloakBackendVolumeSize` | Keycloak backend volume size | `"10Gi"`
`storkRequired` | Scheduler name as stork | `false`
`nodeAffinityLabel` | Label for node affinity for px-central components | `""`
`podAntiAffinity` | PodAntiAffinity will make sure pods are distributed | `false`
`pxcentralDBPassword` | PX-Central cluster store mysql database password | `Password1`
`caCertsSecretName` | Name of the Kubernetes Secret, which contains the CA Certificates. | `""`
`oidc` | Enable OIDC for PX-Central and PX-backup for RBAC | `""`
`oidc.centralOIDC` | PX-Central OIDC | `""`
`oidc.centralOIDC.enabled` | PX-Central OIDC | `true`
`oidc.centralOIDC.defaultUsername` | PX-Central OIDC username | `admin`
`oidc.centralOIDC.defaultPassword` | PX-Central admin password — **not a values input**; auto-generated at install and stored in the `pxcentral-keycloak-http` Secret (retrieve via the command in NOTES.txt) | _(generated)_
`oidc.centralOIDC.defaultEmail` | PX-Central OIDC admin user email | `admin@portworx.com`
`oidc.centralOIDC.keyCloakBackendUserName` | Keycloak backend store username | `keycloak`
`oidc.centralOIDC.keyCloakBackendPassword` | Keycloak backend (PostgreSQL) password — **not a values input**; sourced from the `pxcentral-keycloak-postgresql` Secret (key `postgresql-password`) | _(secret)_
`oidc.centralOIDC.clientId` | PX-Central OIDC client id | `pxcentral`
`oidc.centralOIDC.updateAdminProfile` | Enable/Disable admin profile update action | `true`
`oidc.externalOIDC` | Enable external OIDC provider | `""`
`oidc.externalOIDC.enabled` | Enabled external OIDC provider | `false`
`oidc.externalOIDC.clientID` | External OIDC client ID | `""`
`oidc.externalOIDC.clientSecret` | External OIDC client secret | `""`
`oidc.externalOIDC.endpoint` | External OIDC endpoint | `""`
`securityContext` | Security context for the pod | `{runAsUser: 1000, fsGroup: 1000, runAsNonRoot: true}`
`service.pxCentralUIServiceType` | service type of PX-Central UI (`ClusterIP` or `LoadBalancer`) | `"LoadBalancer"`
`service.pxCentralUIServiceAnnotations` | annotations for PX-Central UI service (use for internal/private LB annotations) | `"{}"`
`service.pxCentralUILoadBalancerSourceRanges` | CIDR allow-list rendered as `spec.loadBalancerSourceRanges` when PX-Central UI is `LoadBalancer` (defense-in-depth) | `[]`

### Image parameters

All images share one **registry** and **repo**. To retarget every image (air-gap / private mirror)
set `images.registry` / `images.repo`. When those are empty, each image uses its own
`images.<key>.registry` / `images.<key>.repo`, and falls back to `docker.io/portworx`.

Image names and default tags are fixed in the chart (`templates/_helpers.tpl`, `px.imageCatalog`),
not in `values.yaml`. Portworx-built images use the release version (`3.3.0-fc1`); third-party images
keep their upstream tag (see [Third-party images](#third-party-images)). Set `images.<key>.tag` only
to override one image's tag.

Parameter | Description | Default
--- | --- | ---
`images.registry` | Shared container registry for all images (empty: use each image's own `registry`) | `""`
`images.repo` | Shared repository (org/namespace) for all images (empty: use each image's own `repo`) | `""`
`images.<key>.registry` | Registry for one image, used only when `images.registry` is empty | `pure-artifactory.dev.purestorage.com/px-docker-remote`
`images.<key>.repo` | Repository for one image, used only when `images.repo` is empty | `portworx`
`images.<key>.tag` | Override the default tag for one image | unset
`images.pullSecrets` | Image pull secrets | `[]`
`images.pullPolicy` | Image pull policy | `Always`
`images.insecureRegistry` | Allow pulling from an insecure (HTTP) registry | `false`
`images.mongodbImageMap.tags` | `mongodb` tags for the intermediate MongoDB upgrade steps (`mongodb5`, `mongodb6`, `mongodb7`, `mongodb8`) | see `values.yaml`

Images (`images.<key>`), with the name and default tag set by the chart:

Image (`images.<key>`) | Image name | Default tag | Module
--- | --- | --- | ---
`pxcentralApiServerImage` | `pxcentral-onprem-api-base` | `3.3.0-fc1` | `pxCentral`
`pxcentralFrontendImage` | `pxcentral-onprem-ui-frontend-private` | `3.3.0-fc1` | `pxCentral`
`pxcentralBackendImage` | `pxcentral-onprem-ui-backend-private` | `3.3.0-fc1` | `pxCentral`
`pxcentralMiddlewareImage` | `pxcentral-onprem-ui-lhbackend-private` | `3.3.0-fc1` | `pxCentral`
`postInstallSetupImage` | `pxcentral-onprem-hook-base` | `3.3.0-fc1` | `pxCentral`
`keycloakBackendImage` | `postgresql` | `18.4` | `pxCentral`
`keycloakFrontendImage` | `keycloak` | `26.6.4_v2` | `pxCentral`
`keycloakLoginThemeImage` | `sb-keycloak-login-theme` | `3.3.0-fc1` | `pxCentral`
`keycloakInitContainerImage` | `busybox` | `1.35.0` | `pxCentral`
`mysqlImage` | `mysql` | `8.4.10` | `pxCentral`
`preSetupHookImage` | `pxcentral-onprem-hook-base` | `3.3.0-fc1` | `pxCentral`
`mysqlInitImage` | `busybox` | `1.35.0` | `pxCentral`
`pxBackupImage` | `px-backup-base` | `3.3.0-fc1` | `pxBackup`
`mongodbImage` | `mongodb` | `8.0.20` | `pxBackup`
`telemetryEnvoyImage` | `edge-envoy` | `2.0.115` | `pxBackup`
`telemetryRegistrationImage` | `ccm-go` | `1.4.54` | `pxBackup`
`telemetryMetricsCollectorImage` | `realtime-metrics` | `1.0.38` | `pxBackup`
`telemetryDataCollectorImage` | `px-backup-telemetry-collector-base` | `3.3.0-fc1` | `pxBackup`
`telemetryLogUploadImage` | `log-upload` | `px-1.1.155` | `pxBackup`
`licenseServerImage` | `px-els` | `3.3.0-fc1` | `pxLicenseServer`
`pxBackupPrometheusImage` | `prometheus` | `v3.13.1` | `pxBackup`
`pxBackupAlertmanagerImage` | `alertmanager` | `v0.33.0` | `pxBackup`
`pxBackupPrometheusOperatorImage` | `prometheus-operator` | `v0.92.0` | `pxBackup`
`pxBackupPrometheusConfigReloaderImage` | `prometheus-config-reloader` | `v0.92.0` | `pxBackup`


### PX-Backup parameters

Parameter | Description | Default
--- | --- | ---
`pxbackup.enabled` | Enabled PX-Backup | `false`
`pxbackup.orgName` | PX-Backup organization name — **not a values input**; fixed to `default` in the chart (`PX_BACKUP_DEFAULT_ORG`) | `default`
`pxbackup.livenessProbeInitialDelay` | initialDelaySeconds for livenessProbe of PX-Backup pod | `1800`
`pxbackup.federated` | Enable federated mode for PX-Backup | `false`
`persistentStorage.mongodbVolumeSize` | mongodb volume size | `"64Gi"`
`persistentStorage.mongoCacheSize` | mongodb cache size in GB | `"4"`
`service.pxBackupUIServiceType` | service type of PX-Backup UI | `"LoadBalancer"`
`service.pxBackupUIServiceAnnotations` | annotations for the PX-Backup UI service | `"{}"`
`service.pxBackupServiceAnnotations` | annotations for the PX-Backup backend service | `"{}"`

### PX-License-Server parameters

The following table lists the configurable parameters of the PX-License-Server chart and their default values.

Parameter | Description | Default
--- | --- | ---
`pxlicenseserver` | PX license server deployment | ``
`pxlicenseserver.enabled` | PX-Central cluster enabled license server component | `false`
`pxlicenseserver.internal` | PX-Central cluster license server | ``
`pxlicenseserver.internal.enabled` | PX-Central cluster license server enabled | `true`
`pxlicenseserver.internal.lsTypeUAT` | PX license server deployment type [UAT] | `false`
`pxlicenseserver.internal.lsTypeAirgapped` | PX license server deployment type [Air-gapped] | `false`
`pxlicenseserver.external.enabled` | External license server enabled | `false`
`pxlicenseserver.mainNodeIP` | External license server main node endpoints | ``
`pxlicenseserver.backupNodeIP` | External license server backup node endpoints | ``
`pxlicenseserver.adminUserName` | PX license server admin user name | `admin`
`pxlicenseserver.adminUserPassword` | PX license server admin user password | `Adm1n!Ur`
`securityContext` | Security context for the pod | `{runAsUser: 1000, fsGroup: 1000, runAsNonRoot: true}`

## Third-party images

Some images this chart deploys are open-source software that Portworx does not build. Portworx
retags the public upstream image (unmodified unless noted below) and publishes it as
`docker.io/portworx/<image>`, which `pure-artifactory.dev.purestorage.com/px-docker-remote/portworx`
mirrors. The tag is the upstream release tag, so the version you run is the upstream version.

Image (`docker.io/portworx/...`) | Used by (`images.<key>`) | Upstream source | License of the main software
--- | --- | --- | ---
`postgresql` | `keycloakBackendImage` | `docker.io/library/postgres` | PostgreSQL License
`keycloak` | `keycloakFrontendImage` | `quay.io/keycloak/keycloak`, rebuilt by Portworx (`_vN` tag suffix) | Apache-2.0
`mysql` | `mysqlImage` | `docker.io/library/mysql` | GPL-2.0
`busybox` | `keycloakInitContainerImage`, `mysqlInitImage` | `docker.io/library/busybox` | GPL-2.0
`mongodb` | `mongodbImage` | `docker.io/library/mongo` | SSPL-1.0
`mongodb` (5.x, 6.x, 7.x tags) | `mongodbImageMap`, intermediate MongoDB upgrade steps only | `docker.io/bitnami/mongodb` | SSPL-1.0 (MongoDB), Apache-2.0 (Bitnami packaging)
`prometheus` | `pxBackupPrometheusImage` | `quay.io/prometheus/prometheus` | Apache-2.0
`alertmanager` | `pxBackupAlertmanagerImage` | `quay.io/prometheus/alertmanager` | Apache-2.0
`prometheus-operator` | `pxBackupPrometheusOperatorImage` | `quay.io/prometheus-operator/prometheus-operator` | Apache-2.0
`prometheus-config-reloader` | `pxBackupPrometheusConfigReloaderImage` | `quay.io/prometheus-operator/prometheus-config-reloader` | Apache-2.0

The license column names the license of the main software only. Each image also contains
operating-system packages under their own licenses; the upstream image is the source of the full
license and source-code information.

All other images in this chart are built by Portworx.
